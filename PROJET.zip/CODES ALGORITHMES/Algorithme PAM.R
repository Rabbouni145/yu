
library(cluster)
library(dbscan) # va me permettre d'utliser ma fonction hull( pour tout simplement entourer mes clusters que j'ai trouvé)
set.seed(1)
n <- 100 ## nombre d'individu
aa<-3  ## Choix du nombre de cluster
ite<-5 # au choix max 6



Coord<- cbind(
  x = runif(5, 0, 5) + rnorm(n, sd = 0.2),
  y = runif(5, 0, 5) + rnorm(n, sd = 0.2)
)
x<-Coord[,1]
y<-Coord[,2] ## coordonnées des individus

Base1<-matrix(0,ncol = length(x),nrow = length(x))
system.time(
  for(i in 1:(length(x)-1)){
    for(j in (i+1):length(x)){
      Base1[j,i]<-sqrt((Coord[i,1]-Coord[j,1])^2 +
                         (Coord[i,2]-Coord[j,2])^2)
    }
    
  }
)
(Base1<-Base1+t(Base1)) ## distance entre individu

            
## algorithme de PAM

f<-sample(1:n,aa,replace = F)# # 3 devient 2
g1<-Base1[,f]
proch<-matrix(0,ncol=aa, nrow=nrow(g1))# 3 devient 2
dist1<-matrix(0,ncol=aa, nrow=nrow(g1))# 3 devient 2
for(i in 1:nrow(g1)){ ####  Distance entre les medoïdes
  
  poss<-which(g1[i,]==min(g1[i,]))
  proch[i,poss]<-i
  dist1[i,poss]<-Base1[i,f[poss]]
}
(diss<-sum(apply(dist1,2,sum)))

f1<-NULL

it<-0 # iteration est a choisi mais prenez un max =6
j<-1
l<-0
ff<-NULL
dis<-diss+1
mem<-matrix(0,ncol=aa,nrow=1000) # 3 devient 2
mem[1,]<-f
f2<-1:n

while(it<ite){

  
if(dis>diss && length(ff)!=(length(f2)-aa)){# 3 devient 2
  l<-l+1
  ff[l]<-f[j]
  (d<-sample(f2[-c(f,ff)],1)) # choix d'un elt objet non-methoide
  f[j]<-d # Actualisation de la listes des methoides
  
   g1<-Base1[,f]
  proch<-matrix(0,ncol=aa, nrow=nrow(g1))# 3 devient 2
  dist1<-matrix(0,ncol=aa, nrow=nrow(g1))# 3 devient 2
  for(i in 1:nrow(g1)){ ####  Distance entre les medoïdes
    poss<-which(g1[i,]==min(g1[i,]))
    proch[i,poss]<-i
    dist1[i,poss]<-Base1[i,f[poss]]
  }
  (dis<-sum(apply(dist1,2,sum)))
  
}
  else if(length(ff)==(length(f2)-aa)){# 3 devient 2
  j<-j+1
  l<-0
  ff<-NULL
  mm<-mem[which(mem[,1]!=0),][nrow(mem[which(mem[,1]!=0),]),]
  mem[j,]<-mm
  f<-mem[j,]
}else{
  mem[j+1,]<-f
      diss=dis
      l<-0
      dis=diss+1
      j<-j+1
      }
  
if(j>length(f)){
  it<-it+1
  l<-0
  dis<-diss+1
  j<-1
}

  
  }



## Representation graphique.


g1<-Base1[,f]
proch<-matrix(0,ncol=aa, nrow=nrow(g1))# 3 devient 2
dist1<-matrix(0,ncol=aa, nrow=nrow(g1))# 3 devient 2
for(i in 1:nrow(g1)){ ####  Distance entre les medoïdes
  
  poss<-which(g1[i,]==min(g1[i,]))
  proch[i,poss]<-i
  dist1[i,poss]<-Base1[i,f[poss]]
}

rg<-matrix(0,ncol=n,nrow=aa) # 3 devient 2
for(i in 1:aa){# 3 devient 2
  
  rg[i,1:length(which(dist1[,i]!=0))]<-which(dist1[,i]!=0)
}

#1



#2

ze1<-NULL
for(i in 1:n){
  ze1[i]<-arrayInd(which(rg==i),dim(rg))[1]
} 
ze1[f]<-0

# avant d'utiliser le ze1 il faut mettre en 0 les valeur aberrante.     
plot(Coord, col=ze1,lwd=5,cex=7) # la strategie pour les couleur c'est d'associer chq individu a sa class.
points(Coord[ze1==0,], pch = 20, col = "grey")
hullplot(Coord,ze1)

row.names(Coord)=seq_len(n)
par(bg="lightgrey", fg="white", pch=16)
plot(Coord,pch=20,xlab = " ",ylab = " ",col=ze1,lwd=5,cex=7)
points(Coord[ze1==0,], pch = 20, col = "grey")
hullplot(Coord,ze1)
text(Coord, row.names(Coord),
     cex=0.65,pos = 1,col = "red")


  title(main = "Positions des villes",
        xlab = "LATITUDE", ylab = "LONGITUDE",
        cex.main = 0.9, font.main= 4, col.main= "red",
        cex.sub = 0.75, font.sub = 4, col.sub = "green",
        col.lab ="darkblue")

hullplot(Coord,ze1,main="Formation des cluster")



# calcul de la sihouette



rg<-cbind(rg,f)

a<-matrix(0,ncol=n,nrow=aa)# 3 nombre de class
s<-a
b<-a
for(i in 1:n){

  classe=arrayInd(which(rg==i),dim(rg))[1]
  aaa<-1:nrow(rg)
  aaa<-aaa[-classe]
  a[classe,i]<-sum(Base1[,i][rg[classe,][rg[classe,]!=0]])/(length(which(rg[classe,]!=0))-1)
  pm<-numeric(length(aaa))
  for(j in aaa){
    
    pm[j]<-sum(Base1[i,][rg[j,][rg[j,]!=0]])/(length(which(rg[j,]!=0)))
  }
  b[classe,i]<-min(pm[aaa])
  s[classe,i]<-(b[classe,i]-a[classe,i])/max(b[classe,i],a[classe,i])
}
S<-apply(s,1,sum)/n ## la sihouette pour tous l'ensemble du cluster.
round(sum(S),2)## la sihouette d'appartenance d'un individu à son cluster respectif.









