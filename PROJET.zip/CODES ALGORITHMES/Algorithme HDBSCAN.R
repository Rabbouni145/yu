
library(igraph)
library(dbscan)
set.seed(665545)
n <- 40 # nombre d'individus
Coord<- cbind(
  x = runif(10, 0, 5) + rnorm(n, sd = 0.3),
  y = runif(10, 0, 10) + rnorm(n, sd = 0.2)
) # Coordonnée

plot(Coord[,1],Coord[,2]) # visualisation es points
x<-Coord[,1]
y<-Coord[,2]
# 2) calcul des distances entre points par differentes methodes

Base1<-matrix(0,ncol = length(x),nrow = length(x))
system.time(
  for(i in 1:(length(x)-1)){
    for(j in (i+1):length(x)){
      Base1[j,i]<-sqrt((Coord[i,1]-Coord[j,1])^2 +
                         (Coord[i,2]-Coord[j,2])^2)
    }
    
  }
)
(Base1<-Base1+t(Base1)) # Distance entre les individus


Base11<-matrix(0,ncol = length(x),nrow = length(x))
system.time(
  for(i in 1:length(x)){
    for(j in 1:length(x)){
      Base11[j,i]<-sqrt((Coord[i,1]-Coord[j,1])^2 +
                         (Coord[i,2]-Coord[j,2])^2)
    }
    Base11[,i]<-Base11[,i]
    
  }
)
Base11 # Distance




## ETAPE 1: Distance d'accessibilité mustuele

k<-2 # choix du paramètre k-distance
Dist<-matrix(0,ncol=length(x),nrow=length(x))
g<-1:length(x)
for(i in 1:length(x)){
  
  i2<-sort(Base11[,i])
  for(j in g[-c(1:i)]){ 
    i1<-sort(Base11[,j])
  Dist[j,i]<-max(i2[k+1],i1[k+1],Base11[j,i])
  Dist
  
  }
}
Dist # distance d'accessibilité mutuelle
  

#  2ieme etape: construction des grappes

## ETAPE 2 et 3: Construction de de l'arbre couvraant et creation de l'arbre hierachique.




Da<-order(Dist)[(cumsum(1:n)[n]+1):(n*n)] # 56:100 devient  cumsum(1:n)[n]+1
l<-arrayInd(which(Dist==Dist[Da[1]]),dim(Dist))
Distn<-matrix(0,ncol=ncol(Dist),nrow=nrow(Dist))
Distn[min(arrayInd(which(Dist==Dist[Da[1]]),dim(Dist)))
      ,max(arrayInd(which(Dist==Dist[Da[1]]),dim(Dist)))]<-Dist[max(arrayInd(which(Dist==Dist[Da[1]]),dim(Dist))),
                 min(arrayInd(which(Dist==Dist[Da[1]]),dim(Dist)))]

Distn[min(arrayInd(which(Dist==Dist[Da[2]]),dim(Dist)))
      ,max(arrayInd(which(Dist==Dist[Da[2]]),dim(Dist)))]<-Dist[max(arrayInd(which(Dist==Dist[Da[2]]),dim(Dist))),
                                                                min(arrayInd(which(Dist==Dist[Da[2]]),dim(Dist)))]
system.time(for(i in 1:(length(Da)-1)){ 
  if(Dist[Da[i]]!=Dist[Da[i+1]]){ 
l<-rbind(l,arrayInd(which(Dist==Dist[Da[i+1]]),dim(Dist)))
for(j in 1:nrow(arrayInd(which(Dist==Dist[Da[i+1]]),dim(Dist)))){ 
  f<-arrayInd(which(Dist==Dist[Da[i+1]]),dim(Dist))[j,]
  Distn[f[1],f[2]]<-Dist[max(f),min(f)]
  }

}
})

as.numeric(t(l))
M<-numeric(n) # 10 devient n
M1<-matrix(0,ncol=ncol(l),nrow=nrow(l))
j=0
j1<-0
mp<-matrix(0,ncol=4000,nrow=4000) # 45,45 devient n
Dist<-Dist+t(Dist)
myg1<-graph.adjacency(Distn,mode = "undirected",weighted = TRUE)
plot.igraph(myg1,layout = Coord)# VISUALISATION DES POINT ET LEUR DISTANCE D'ACCESSIBILITE
PO<-matrix(0,ncol=4000,nrow=4000) # 10 devient n
Epsilon<-matrix(0,n)
Epsilon2<-matrix(0,n)
Epsiln<-matrix(0,n)
poids<-numeric(4000) # 40 comme PO


## Algorithme de Hruskal pour la representation de l'arbre couvrant minimum
for(i in order(E(myg1)$weight)){
  
 v1<-as.numeric(get.edgelist(myg1)[i,1])
 v2<-as.numeric(get.edgelist(myg1)[i,2])
  if(M[v1]==0 && M[v2]==0){
    j=j+1
    j1<-j1+1
    Epsilon[v1]<-E(myg1)$weight[i]
    Epsilon[v2]<-E(myg1)$weight[i]
    M1[j,]=c(v1,v2)
    PO[j,1:2]<-c(v1,v2)
    poids[j]<-(1/E(myg1)$weight[i])
    M[v1]=j1;M[v2]=j1
    mp[v1,v2]<-Dist[v1,v2]
    mp[v2,v1]<-Dist[v1,v2] 
      # stock la distance des news
    E(myg1)[i]$color="red"
    plot.igraph(myg1,layout=Coord,main="Kruskal")
    Sys.sleep(0.1)
    if(length(unique(M))==1) break
    
  }else if(M[v2]==0 || M[v1]==0){
    j=j+1
    
    M1[j,]=c(v1,v2)
    mp[v1,v2]<-Dist[v1,v2]
    mp[v2,v1]<-Dist[v1,v2] 
    
    if(M[v2]==0){
      
      Epsilon[v2]<-E(myg1)$weight[i]
      po1<-arrayInd(which(PO==v1),dim(PO))
      PO[j,1:(length(PO[po1[nrow(po1),1],][PO[po1[nrow(po1),1],]!=0])+1)]<-c(PO[po1[nrow(po1),1],][PO[po1[nrow(po1),1],]!=0],v2)
      poids[j]<-(1/E(myg1)$weight[i])
      M[v2]=M[v1]
      E(myg1)[i]$color="red"
      plot.igraph(myg1,layout=Coord,main="Kruskal")
      Sys.sleep(0.1)
      if(length(unique(M))==1) break
      
    }else{
      Epsilon[v1]<-E(myg1)$weight[i]
    po1<-arrayInd(which(PO==v2),dim(PO))
    PO[j,1:(length(PO[po1[nrow(po1),1],][PO[po1[nrow(po1),1],]!=0])+1)]<-c(PO[po1[nrow(po1),1],][PO[po1[nrow(po1),1],]!=0],v1)
    poids[j]<-(1/E(myg1)$weight[i])
    M[v1]=M[v2]
    E(myg1)[i]$color="red"
     plot.igraph(myg1,layout=Coord,main="Kruskal")
    Sys.sleep(0.1)
    if(length(unique(M))==1) break
          }
    
    
   
  }else{  
    if(M[v2]==M[v1]){
      M1[i,]=0
      
     
      
    }else{ 
      j=j+1
      po1<-arrayInd(which(PO==v2),dim(PO))
      po11<-PO[po1[nrow(po1),1],][PO[po1[nrow(po1),1],]!=0]
      po2<-arrayInd(which(PO==v1),dim(PO))
      po22<-PO[po2[nrow(po2),1],][PO[po2[nrow(po2),1],]!=0]
      PO[j,1:length(c(po11,po22))]<-c(po11,po22)
      poids[j]<-(1/E(myg1)$weight[i])
      M1[j,]=c(v1,v2)
      Epsilon2[v2]<-Dist[v1,v2]
      M[which(M==M[v2])]=M[v1]
      mp[v1,v2]<-Dist[v1,v2]
      mp[v2,v1]<-Dist[v1,v2] 
      E(myg1)[i]$color="red"
        plot.igraph(myg1,layout=Coord,main="Kruskal")
      Sys.sleep(0.1)
      if(length(unique(M))==1) break
      
      }
      
  }
  
 if(length(unique(M))==1) break
  
}






#3





## ETAPE 4: Condensation de l'arbre hierachique.


POO<-PO[PO[,1]!=0,]
Noeud<-matrix(0,nrow=100)
PNoeud<-matrix(0,nrow=100)
k<-nrow(POO)
m<-3 ## parametre qui determine le nombre de points faut t'il avoir pour etre considéré comme un cluster .
t<-1 # initialisation
Mere_filles<-matrix(0,nrow=3,ncol=n)
seg<-numeric(1000) ## permet de stocker tous les numeros de neoud retenus pour creer les groupes.

## Creation des clusters plat(les clusters à retenir)
while(is.na(k)!=TRUE){
  
  k11<-arrayInd(which(POO[1:(k-1),]==POO[k,1]),dim(POO[1:(k-1),]))[nrow(arrayInd(which(POO[1:(k-1),]==POO[k,1]),dim(POO[1:(k-1),]))),1]   ## de la derniere ligne qui contient 3: ou 3 appartient à l'une des fieule
  k2<-POO[k11,][POO[k11,]!=0] ## l'une des fille de la mere 
  ks<-table(factor(k2,levels=POO[k,][POO[k,]!=0]))
  k1<-as.numeric(names(ks[ks==0])) ## l'une des fille de la mere k
  k22<-arrayInd(which(POO[1:(k-1),]==k1[1]),dim(POO[1:(k-1),]))[nrow(arrayInd(which(POO[1:(k-1),]==k1[1]),dim(POO[1:(k-1),]))),1]
  
  if(length(k1)>=m && length(k2)>=m){
    Noeud[k11,1]<-k11
    Noeud[k22,1]<-k22
    PNoeud[k11,1]<-k11
    PNoeud[k22,1]<-k22
    
    
  
    if(length(k1)==2){
      PNoeud[k22,1]<-0
    }
    if(length(k2)==2) 
    {PNoeud[k11,1]<-0
    }
    
    
    
  }else{
    if(length(k1)>=m && length(k2)<m){
      PNoeud[k22,1]<-k22
    }else if(length(k1)<m && length(k2)>=m)
    {PNoeud[k11,1]<-k11}
    
  }
  
  k<-PNoeud[PNoeud[,1]!=0][1]
  PNoeud[k]<-0
  
  
  
}



## Etape 5: Selectionne des clusters plats

epsi<-1.4 ## parametre epsilon pour trouver les clusters qui doivent etre selectionné finalement (etape 5)
Noeud[Noeud[,1]!=0]
Poids_Noeud<-poids[Noeud[Noeud[,1]!=0]]
Noeud[Noeud[,1]!=0][which(Poids_Noeud<=epsi)] ## liste des choisi en fonction du choix de la valeur epsi




## Etape 6: ettiquette (facultatif)

Cluster<-matrix(0,ncol=4000,4000)
for(i in Noeud[Noeud[,1]!=0][which(Poids_Noeud<=epsi)]){
  
Cluster[1:length(POO[i,][POO[i,]!=0]),i]<-POO[i,][POO[i,]!=0]
    
}
Cluster[,Cluster[1,]!=0]
ze1<-NULL
for(i in 1:n){

  ze1[i]<-arrayInd(which(Cluster==i),dim(Cluster))[1,][2]
}  
(ze1[is.na(ze1)]<-0)



# Formation des cluster
# avant d'utiliser le ze1 il faut mettre en 0 les valeur aberrante.     
plot(Coord, col=ze1) # la strategie pour les couleur c'est d'associer chq individu a sa class.
points(Coord[ze1==0,], pch = 5, col = "grey")
hullplot(Coord,ze1,main="Formation des clusters")











