library(shiny)
library(bs4Dash)
library(htmlwidgets)
library(slickR)
library(shinyalert)
library(DT)
library(dbscan)
library(shinycustomloader)
library(ggplot2)
library(igraph)
library(shinyWidgets)
library(bubblyr)
library(spsComps)
library(mailtoR)










    ui = dashboardPage(
        header = dashboardHeader(rightUi = userOutput("user"),span(h2("Algorithmes De Classification Non-Supervisé.",br(),"NOTE OBTENUE : 19.75/20"),style="color:gold") %>%
                                     animateAppendNested("horizontal")
                                 ,
                                 title =dashboardBrand(
                                     title =em("UNIVERSITE BRETAGNE"),
                                     color = "primary",
                                     href = "welcome",
                                     image = phota # welco
                                 )
        ),
        sidebar = dashboardSidebar(
            
            
            
            sidebarUserPanel(
                
                image = welcogif,
                name = h4(span(em("Hi Visiteur!",style="color:Grey"))) %>%
                    animateAppendNested("tada")
            ),
            sidebarMenu(
                 
                menuItem("TER",tabName = "tp1",icon =icon("fal fa-wallet")),hr(),
                menuItem(strong("Primes"),tabName = "tpn",icon = icon("fas fa-question")),hr(),
                numericInput("Nbreind",icon("fas fa-users"),min = 1, value = " "),hr(),
                menuItem(strong("Data / Graphe"),tabName = "tp5",icon = icon("fas fa-eye-slash")),hr(),br(),br(),br(),br(),hr(),
                menuItem(strong("A-Propos"),tabName = "tp3",icon = icon("fas fa-info")),hr(),
                menuItem(strong("Questions"),tabName = "tp2",icon = icon("fas fa-question"))
                 )
            
            
            
            
        ),
        body = dashboardBody(useShinyalert(),
                             tabItems(
                                 
                                 tabItem(
                                     tabName = "tp1",
                                     fluidRow( 
                                         column(12,
                                                tabBox(width = NULL,
                                                       tabPanel(h5(strong("Accueil")) ,hr(),
                                                             fluidRow(
                                                                   column(1),
                                                                    column(10,
                                                                           callout(width = 15,title=" ",
                                                                                      elevation = 4,
                                                                                      status = "success",
                                                                                      sli2<- slickR(obj =c(l11,l2,acceuill2,acceuill3,acceuill4),height = 480, width = "95%") + 
                                                                                          settings(dots = TRUE, autoplay = TRUE,autoplaySpeed = 1200,adaptiveHeight = TRUE)
                                                                                      
                                                                                      )
                                                                           
                                                                    ),column(1)
                                                                    
                                                                    
                                                                ),fluidRow(
                                                                    column(12,br(),br(),
                                                                           hr(),p(),br(),span(h2("INTRODUCTION", class = "text-primary"),style="color:Grey") %>%
                                                                               animateAppendNested("pulse"),br(),br(),p(test1,br(titre),br(titree),h6(soustitre1, class = "text-primary") %>%
                                                                                                                              animateAppendNested("tada"),br(),br(),h6(soustitre2, class = "text-primary") %>%
                                                                                                                            animateAppendNested("tada")),h6(soutritre4, class = "text-primary") %>%
                                                                               animateAppendNested("tada"),
                                                                           br(),br(),br(),br(),soustitre3)
                                                                ) 
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                       ),
                                                       tabPanel(h5(strong("Présentations")),hr(),
                                                                fluidRow(
                                                                    column(6,
                                                                           callout(width = 15,
                                                                                   title =h2("Algorithme de PAM", class = "text-primary") %>%
                                                                                       animateAppendNested("pulse"),
                                                                                   elevation = 4,
                                                                                   status = "danger",
                                                  pam1,br(),pam11,br(),br(),pam111,br(),pam1111
                                                                           )
                                                                           
                                                                           
                                                                           
                                                                           
                                                                    ),
                                                                    
                                                                    column(6,
                                                                           
                                                                           box(
                                                                               title ="",
                                                                               closable =FALSE,
                                                                               elevation = 5,
                                                                               width = 12,
                                                                               height = "450px",
                                                                               headerBorder = FALSE,
                                                                               solidHeader = FALSE,
                                                                               collapsible = TRUE
                                                                               , sidebar = boxSidebar(background = "white",
                                                                                   id = "mycardsidebar1",
                                                                                   p("Sidebar Content"),width = 100,heigth=20,icon = 
                                                                                       shiny::icon("eye"),
                                                                                   carousel(
                                                                                       id = "mycarousel",
                                                                                       
                                                                                       carouselItem(
                                                                                           caption = "Item 2",
                                                                                           tags$img(src = imapam1)
                                                                                       ),
                                                                                       carouselItem(
                                                                                           caption = "Item 25",
                                                                                           tags$img(src = imapam)
                                                                                       )
                                                                                       #
                                                                                   )
                                                                               
                                                                                   
                                                                                   
                                                                                   
                                                                                   
                                                                                   
                                                                                   
                                                                                   
                                                                                   
                                                                                   
                                                                                       
                                                                               ),
                                                        pam22,br(),pam2,br(),pam2222,br(),br(),em(pam222)
                                                                               
                                                                               
                                                                               
                                                                           )
                                                                    )
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                ),hr(),hr(),
                                                                fluidRow(
                                                                    column(6,
                                                                           callout(width = 15,
                                                                                   title =h2("Algorithme De DBSCAN", class = "text-primary") %>%
                                                                                       animateAppendNested("pulse"),
                                                                                   
                                                                                   
                                                                                   elevation = 4,
                                                                                   status = "danger",
                                                               dbscan1,br(),dbscan11,br(),br(),dbscan111, br(),br(),dbscan1111,br(),
                                                               br(),dbscan11111)
                                                                           
                                                                           
                                                                           
                                                                           
                                                                    ),
                                                                    
                                                                    column(6,
                                                                           
                                                                           box(dbs11111,br(),br(),dbscan111111,br(),dbc,br(),dbscan2,
                                                                               title ="",
                                                                               closable =FALSE,
                                                                               elevation = 5,
                                                                               width = 12,
                                                                               height = "450px",
                                                                               headerBorder = FALSE,
                                                                               solidHeader = FALSE,
                                                                               collapsible = TRUE
                                                                               , sidebar = boxSidebar(
                                                                                   id = "mycardsidebar11",
                                                                                   p("Sidebar Content"),width = 100,icon = 
                                                                                       shiny::icon("eye"),background ="white" ,
                                                                                   
                                                                                   
                                                                                   carousel(
                                                                                       id = "mycarousel1",
                                                                                       carouselItem(
                                                                                           caption = "Item 111",
                                                                                           tags$img(src = imadbscan1)
                                                                                       ),
                                                                                       
                                                                                       
                                                                                       carouselItem(
                                                                                           caption = "Item 2011",
                                                                                           tags$img(src = imadbsca3)
                                                                                       )
                                                                                       
                                                                                   )
                                                                                   
                                                                                   
                                                                                   
                                                                                   
                                                                               )
                                                                               
                                                                           ))
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                ),hr(),hr(),
                                                                
                                                                
                                                                
                                                                fluidRow(
                                                                    column(6,
                                                                           callout(width = 15,
                                                                                   title =h2("Algorithme De HDBSCAN", class = "text-primary") %>%
                                                                                       animateAppendNested("pulse"),
                                                                                   elevation = 5,
                                                                                   status = "danger",
                                                                                   hdbscan1,br(),br(),etape1,br(),exp1,br(),br(),etape2,br(),exp2,br()
                                                                                   
                                                                           )
                                                                           
                                                                           
                                                                           
                                                                           
                                                                    ),
                                                                    
                                                                    column(6,
                                                                           
                                                                           box(
                                                                               title ="",
                                                                               closable =FALSE,
                                                                               elevation = 5,
                                                                               width = 12,
                                                                               height = "450px",
                                                                               headerBorder = FALSE,
                                                                               solidHeader = FALSE,
                                                                               collapsible = TRUE
                                                                               , sidebar = boxSidebar(
                                                                                   id = "mycardsidebar2",
                                                                                   p("Sidebar Content"),width = 100,background = "white",icon = 
                                                                                       shiny::icon("eye"), 
                                                                                   carousel(
                                                                                       id = "mycarousel11",
                                                                                       carouselItem(
                                                                                           caption = "Item 1111",
                                                                                           tags$img(src = imagdbscan1)
                                                                                       ),
                                                                                       carouselItem(
                                                                                           caption = "Item 2111",
                                                                                           tags$img(src = imagdbscan2)
                                                                                       ),
                                                                                       carouselItem(
                                                                                           caption = "Item 21111",
                                                                                           tags$img(src = imagdbscan3)
                                                                                       ),
                                                                                       carouselItem(
                                                                                           caption = "Item 31111",
                                                                                           tags$img(src = imagehdbscan4)
                                                                                       )
                                                                                       
                                                                                       
                                                                                   )
                                                                                   
                                                                                   
                                                                                   
                                                                                   
                                                                                   
                                                                                   
                                                                                   
                                                                               ),etape3,br(),exp3,br(),br(),etape4,br(),exp4,br(),br(),etape5
                                                                               #sli1<-slickR(obj =c(l11,l2),height = 380, width = "95%") + 
                                                                               # settings(dots = TRUE, autoplay = TRUE,autoplaySpeed = 1000,adaptiveHeight = TRUE)
                                                                               
                                                                               
                                                                               
                                                                               
                                                                           )
                                                                    )
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                )
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                       ),
                                                       tabPanel(h5(strong("Algorithme de PAM")),
                                                                hr(),
                                                                fluidRow(
                                                                    column(1,
                                                                           dropdownButton(
                                                                    tags$h3(h3(span("Paramètres",style="color:green"), class = "text-primary") %>%
                                                                                animateAppendNested("falling")),
                                                                    sliderInput(inputId = 'clusters', label = 'Nombre de Clusters', value = "", min = 2, max = 9),
                                                                    sliderInput("iteration","Nombre d'itération",value = "",min=1,max=6),
                                                                    actionButton("lanc1","Lancé",icon =icon("fas fa-paper-plane"),flat=T),
                                                                    circle = FALSE, status = "danger", icon = icon("gear"), width = "300px",
                                                                    tooltip = tooltipOptions(title = "Click to see inputs !"),up=TRUE,size = "sm"
                                                                )),
                                                                column(8,
                                                                       
                                                                       callout(width = 100,
                                                                               title =h3("Visualisation PAM"),hr(),
                                                                               elevation = 5,
                                                                               status = "danger",
                                                                       
                                                                       
                                                                       
                                                                               withLoader(plotOutput("plot11"), type="html", loader="dnaspin"))
                                                             ,actionButton("btn",h5(span("Ce qui faut Savoir",style="color:green"), class = "text-primary") %>%
                                                                               animateAppendNested("float"))
                                                                ),column(3,
                                                                         
                                                                         callout(width = 15,
                                                                                 title =h3("Coefficient de Silhouette"),hr(),
                                                                                 elevation = 5,
                                                                                 status = "danger",
                                                                                 em("Le Coefficient de Silhouette permet de quantifier à quel point un clustering répond
                                                                              à ces deux à ces exigences:"),em(span("Homogénéité",style="color:red")),em("et"),em(span("Séparation.",style="color:red")),br(),br(),hr(),em(p("Cliquez sur ce bouton ci dessous pour l'interprétation du coefficient de Silhouette. 
                                                                                                                                                         ")),br(),actionButton("btn1", h5(span("Silhouette",style="color:green"), class = "text-primary") %>%
                                                                                                                                                                                   animateAppendNested("flash")))
                                                                )
                                                                )
                                                       )
                                                       ,
                                                       
                                                       
                                                       
                                                       
                                                       tabPanel(h5(strong("Algorithme DBSCAN")),
                                                                hr(),
                                                                fluidRow(
                                                                    column(1,dropdownButton(
                                                                        tags$h3(h3(span("Paramètres",style="color:green"), class = "text-primary") %>%
                                                                                    animateAppendNested("falling")),
                                                                        numericInput('Eps', 'Epsilon', value = "",min=0),
                                                                        numericInput("Minps","Min-point",value = "",min=1.2),
                                                                        actionButton("lanc2","Lancé",icon =icon("fas fa-paper-plane"),flat=T),
                                                                        circle = FALSE, status = "info", icon = icon("gear"), width = "300px",
                                                                        tooltip = tooltipOptions(title = "Click to see inputs !"),up=TRUE,size = "sm"
                                                                    )),
                                                                    column(8,
                                                                           callout(width = 100,
                                                                                   title =h3("Visualisation DBSCAN"),hr(),
                                                                                   elevation = 5,
                                                                                   status = "info",
                                                                                   
                                                                           withLoader(plotOutput("plot3"), type="text", 
                                                                                      loader=list(
                                                                               marquee("Merci de veiller patienter",scrollamount = 9), 
                                                                               marquee("C'est un algorithme de DBSCAN basé sur la densité",direction = "right"),
                                                                               marquee("Cet algorithme peut stimuler plus 800 individus en moins de 15 sécondes.",direction = "left",scrollamount = 8),
                                                                               marquee("Cet algorithme est programmé uniquement avec le langage R",direction = "left",scrollamount = 8)
                                                                           )
                                                                           )
                                                                           )
                                                                           ),
                                                                           column(3,
                                                                                  
                                                                                  callout(width = 15,
                                                                                          title =span(h3("Valeurs Optimales Min-Points & Eps"),style="color:green"),hr(),
                                                                                          elevation = 5,
                                                                                          status = "info",
                                                                                          em("Après avoir inseré le nombre d'individu, L'algorithme vous propose des valeurs optimales de Minp et Epsilon.") ,
                                                                                          em(p("pour visualiser cette proposition, cliquez sur le Boutton ci dessous. ")))
                                                                                          
                                                                                          ,actionButton("btn6", h5(span("Valeurs optimales",style="color:green"), class = "text-primary") %>%
                                                                                                            animateAppendNested("flash"))  )
                                                                                  
                                                                           )
                                                                           
                                                                           
                                                                           )
                                                                
                                                                ,
                                                       tabPanel(h5(strong("Algorithme HDBSCAN")),
                                                                hr(),
                                                                fluidRow(
                                                                    column(1,dropdownButton(
                                                                        tags$h3(h3(span("Paramètres",style="color:green"), class = "text-primary") %>%
                                                                                    animateAppendNested("falling")),
                                                                        numericInput('Eps1', 'Epsilon', value = "",min=0.00001),
                                                                        numericInput("Minps1","Min-points",value = "",min=1),
                                                                        numericInput("kdist","k-distances",value = "",min=1),
                                                                        numericInput("kdist1","Min-cluster",value = "",min=1),
                                                                        actionButton("lanc3","GO",icon =icon("fas fa-paper-plane"),flat=T),
                                                                        circle = FALSE, status = "warning", icon = icon("gear"), width = "300px",
                                                                        tooltip = tooltipOptions(title = "Click to see inputs !"),up=TRUE,size = "sm"
                                                                    )),
                                                                    column(8,
                                                                           callout(width = 100,
                                                                                   title =h3("Visualisation HDBSCAN"),hr(),
                                                                                   elevation = 5,
                                                                                   status = "warning",
                                                                                   
                                                                                   withLoader(plotOutput("plot4"), type="text", 
                                                                                              loader=list(
                                                                                                  marquee("Merci de veiller patienter",scrollamount = 10), 
                                                                                                  marquee("Vous être prêt à visualiser l'arbre minimum couvrant.",direction = "right"),
                                                                                                  marquee("L'algorithme n'est que programmé avec le langage R. il n'inclut pas d'autres langages donc le temps d'attente peut être long pour des individus >100.",direction = "left",scrollamount = 7)
                                                                                              )
                                                                                   )
                                                                           )
                                                                    ),
                                                                    
                                                                    column(3,
                                                                           
                                                                           callout(width = 15,
                                                                                   title =h3("Informations"),hr(),
                                                                                   elevation = 5,
                                                                                   status = "warning",
                                                                                   em("L'arbre couvrant minimum a été réaliser en utilisant l'algorithme de Kruskal.") ,
                                                                                   em(p("Pour plus d'informations sur l'algorithme veuillez cliquer sur le menu 'Pour aller plus loin'.")))
                                                                           
                                                                           ,actionButton("btn7", h4("Cluster", class = "text-primary") %>%
                                                                                             animateAppendNested("pulse")))
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                )
                                                                
                                                                
                                                                
                                                                )
                                                       
                                                       
                                                       
                                                       
                                                       
                                                       
                                                       
                                                       
                                                       
                                                       
                                                       
                                                       
                                                       
                                                       
                                                       
                                                       
                                                       
                                                       
                                                       
                                                       
                                                       
                                                       
                                                )
                                         )
                                         
                                         
                                         
                                         
                                     )
                                 ),
                                 
                                 tabItem(
                                   tabName = "tpn",
                                   em(span(h2("Simulation des primes et provisions "),style="color:blue")),hr(),hr(),
                                   fluidRow(
                                     
                                     column(4,callout(width = 100,
                                                      title =h3("PRIMES"),hr(),
                                                      elevation = 5,
                                                      status = "warning",
                                                      
                                                      textOutput("value"),
                                                      conditionalPanel("input.c1==4 || input.c1>=4",
                                                      actionButton("PRIME_CALCUL", h4("CALCUL", class = "text-primary") %>%
                                                                     animateAppendNested("pulse")))
                                     ),
                                     callout(width = 100,
                                             title =h3("INFO CHARGEMENTS"),hr(),
                                             elevation = 5,
                                             status = "info",
                                             actionButton("Info_charg", h4("chargements et taux technique", class = "text-primary") %>%
                                                                             animateAppendNested("pulse"))
                                     ),
                                     callout(width = 100,
                                             title =h3("MES PERSPECTIVES"),
                                             elevation = 5,
                                             status = "info",br(),hr(),
                                             " - Optimiser mes codes",br(),
                                             " - Terminer la partie provisions mathématiques",br(),
                                             " - Utiliser des contrats plus complexes à deux têtes", br(),
                                             " - Utiliser les rentes jumeaux, rente de réversion et  rente sur 2 têtes."
                                             
                                             
                                     )
                                     
                                     
                                     ),
                                     
                                     column(4,
                                            callout(width = 100,
                                                    title =h3("Insère les informations"),hr(),
                                                    elevation = 5,
                                                    status = "warning",
                                                    actionButton("c1", h4("SUIVANT", class = "text-primary") %>%
                                                                   animateAppendNested("pulse")),
                                                    
                                                    conditionalPanel("input.c1==1",
                                                    textInput("A1","NOM",value = "Entrer nom...."),
                                                    textInput("A2","PRENOM",value = "Entrer Prenon...."),
                                                    numericInput('Age_homme', 'Votre Age', value = "",min=1),
                                                    radioButtons("Sexe", label = h3("GENRE"),
                                                     choices = list("M" = 1, "F" = 2),selected = 1)
                                                    ),
                                                    
                                                    conditionalPanel("input.c1==2", h3("ADRESSE"),hr(), 
                                                                     textInput("B1","PAYS DE NAISSANCE",value = "Entrer Pays...."),
                                                                     textInput("B2","Ville",value = "Entrer Ville...."),
                                                                     textInput("B3","Lieu de residence",value = "Entrer lieu...."),
                                                                     textInput("B4","Contacte",value = "Entrer contacte....")
                                                                     
                                                                     
                                                    )
                                                    
                                                    ,
                                                    conditionalPanel("input.c1==3",h3(""),hr(),
                                                                     radioButtons("Contrats", label = span(strong(h3("Choisis ton Contrat")),style="color:red"),
                                                                      choices = list("Prévoyance décès" = 1, "Contrat pluriannuel" = 2,
                                                                                     "Contrat vie entière"=3),selected = ""),hr(),hr(),
                                                                     br(),strong("Pour une compréhension de ces differents types de contrat veuillez cliquer sur le boutton Info"),hr(),
                                                                     actionButton("INFO", h4("INFO")),hr(),br()
                                                                     
                                                                        
                                                    ),conditionalPanel("input.c1==3 && input.Contrats=='1'",h3("INFORMATIONS DU BENEFICAIRE"),hr(),
                                                                       textInput("C1","",value = "Entrer Nom du benefiaire...."),
                                                                       textInput("C2","",value = "Entrer prenom du benefiaire...."),
                                                                       textInput("C4","",value = "Entrer Ville du benefiaire...."),
                                                                       textInput("C5","",value = "Entrer contacte du beneficiaire...."),
                                                                       numericInput('C3', 'Age', value = "",min=1),
                                                                       radioButtons("Sexe_Beneficiaire", label = "Genre",
                                                                                    choices = list("M" = 1, "F" = 2),selected = ""),hr(),hr(),
                                                                       
                                                                       radioButtons("Rente", label = h3("RENTES"),
                                                                                    choices = list("Rente de conjoint" = 1,
                                                                                                   "Rente temporaire" = 2),selected = "")
                                                                       
                                                                       
                                                    ),conditionalPanel("input.c1>=4 && input.Contrats=='1' ",h3(""),hr(),
                                                                       numericInput('MontnatDA22', 'Insère la Rente', value = "",min=1),hr(),hr(),br() ,
                                                                       h4("Après avoir insèré la valeur de la rente cliquez sur le boutton CALCUL à gauche")
                                                                       
                                                    ),conditionalPanel(" input.c1>=4 && input.Contrats=='3'",hr(),
                                                                       radioButtons("Capital_dècès", label = "Types",
                                                                                    choices = list("Temporaire" = 1, "Viagère" = 2),selected = "")
                                                                       
                                                    ),
                                                    conditionalPanel(" input.Contrats=='3' && input.Capital_dècès=='2' && input.c1>=4 ",hr(),
                                                                     numericInput('MontantCd', 'Montant du dédommagement', value = "",min=1),
                                                                     h4("Après avoir insèré la valeur du montant cliquez sur le boutton CALCUL à gauche")
                                                                     
                                                    ),conditionalPanel("input.Contrats=='3' && input.Capital_dècès=='1' && input.c1>=4 ",hr(),
                                                                       numericInput('MontantCd1', 'Montant du dédommagement', value = "",min=1),
                                                                       numericInput('Duréé_Contrat', 'Durée du contrat', value = "",min=1),
                                                                       h4("Après avoir insèré la valeur du montant et la durée cliquez sur le boutton CALCUL à gauche")
                                                                       
                                                                       
                                                    )
                                                    ,conditionalPanel("input.Rente=='2' && input.c1==4 && input.Contrats=='1'",hr()
                                                                       ,numericInput('Durée_M1', "Durée de l'indémnisation", value = "",min=1)
                                                                       
                                                                       
                                                    )
                                                    
                                                    
                                                    ,conditionalPanel("input.c1==3 && input.Contrats=='2'", hr(),
                                                                      selectInput("selectC", label = "Choisissez votre type de modalité",
                                                                                  choices = list("année" = 1, "Semestre" = 2, "Trimestre" = 3,
                                                                                                 "Mois"=4),
                                                                                  selected = NULL),hr()
                                                                      
                                                                      
                                                                                                                                        
                                                                                                                                        
                                                    
                                                                      
                                                                      
                                                    ),conditionalPanel("input.c1==4 && input.Contrats=='2' ",hr(),
                                                                       selectInput("selectD", label ="Sélection le type de dédommagement?",
                                                                                   choices = list("Côtiser pendant k années et dédommagement illimité" = 3,
                                                                                                  "Côtiser pendant k année (s) et dédommagement pendant n année"=4),
                                                                                   selected = NULL))
                                                  
                                                                     
                                                    ,
                                                    conditionalPanel("input.c1>=4 && input.Contrats=='2' && input.selectD=='3'",hr(),
                                                                     
                                                                     numericInput('annee_D1', "Combien d'année cotisez-vous ?", value = "",min=1)
                                                                     
                                                    ),
                                                    conditionalPanel("input.c1==4 && input.Contrats=='2' && input.selectD=='4'",hr(),
                                                                     
                                                                     numericInput('annee_D2', "Combien d'année cotisez-vous ?", value = "",min=1),
                                                                     numericInput('duree_D1', 'Durée du dédommagement', value = "",min=1)
                                                                     
                                                                     
                                                    ),
                                                    conditionalPanel("input.c1>=5 && input.Contrats=='2'",hr(),
                                                                     numericInput('Montant_D4', "Combien voulez-vous epargner ?", value = "",min=1),br(),
                                                                     h5("Cliquez ensuite sur le boutton : CALCUL")
                                                                     
                                                                     
                                                                   )
                                                    
                                                    
                                            )),
                                                   column(4,
                                                            callout(width = 100,
                                                                    title =h3("DESCRIPTIONS DU CONTRAT
                                                                              "),hr(),
                                                                    elevation = 5,
                                                                    status = "warning",
                                                                    conditionalPanel("input.PRIME_CALCUL>=1 && input.Capital_dècès=='1' && input.Contrats=='3' ",hr() 
                                                                                     ,actionButton("DESCRIPTION0", h4("DESCRIPTION", class = "text-primary") %>%
                                                                                                    animateAppendNested("pulse"))
                                                                                     
                                                                    ),
                                                                    conditionalPanel("input.PRIME_CALCUL>=1 && input.Capital_dècès=='2'",hr()
                                                                                     ,
                                                                                     actionButton("DESCRIPTION01", h4("DESCRIPTION", class = "text-primary") %>%
                                                                                                    animateAppendNested("pulse"))),
                                                                    
                                                                    
                                                                    conditionalPanel("input.PRIME_CALCUL>=1 && input.Rente=='1' && input.Contrats=='1' ",hr()
                                                                                     ,
                                                                                     actionButton("DESCRIPTION1", h4("DESCRIPTION", class = "text-primary") %>%
                                                                                                    animateAppendNested("pulse"))
                                                                                     
                                                                    ),
                                                                    
                                                                    
                                                                    conditionalPanel("input.PRIME_CALCUL>=1 && input.Rente=='2' ",hr()
                                                                                     ,
                                                                                     actionButton("DESCRIPTION2", h4("DESCRIPTION", class = "text-primary") %>%
                                                                                                    animateAppendNested("pulse"))
                                                                                     
                                                                    ),
                                                                    
                                                                    conditionalPanel("input.PRIME_CALCUL>=1 && input.selectD=='3' && input.Contrats=='2' ",hr()
                                                                                     ,
                                                                                     actionButton("DESCRIPTION03", h4("DESCRIPTION", class = "text-primary") %>%
                                                                                                    animateAppendNested("pulse"))
                                                                                     
                                                                    ),
                                                                    conditionalPanel("input.PRIME_CALCUL>=1  && input.selectD=='4'",hr()
                                                                                     ,
                                                                                     actionButton("DESCRIPTION04", h4("DESCRIPTION", class = "text-primary") %>%
                                                                                                    animateAppendNested("pulse"))
                                                                                     
                                                                    )
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                            ),
                                                          
                                                          callout(width = 100,
                                                                  title =h3(""),hr(),
                                                                  elevation = 5,
                                                                  status = "warning",
                                                                  actionButton("PROVISION", h4("PROVISION MATHEMATIQUE", class = "text-primary") %>%
                                                                                 animateAppendNested("pulse")))
                                                          )
                                            
                                     )
                                     
                                   
                                 ),
                                 
                                 
                                 
                                 tabItem(
                                     tabName = "tp5",
                                     em(span(h2("Visualisation Data.frame & Graphe"),style="color:blue")),hr(),hr(),
                                     fluidRow(
                                         column(2,actionButton("btn3", strong(span("GRAPHE",style="color:green")))),
                                         column(8,
                                         DTOutput("data1") 
                                                            )
                                         
                                     )
                                 ),
                                 tabItem(
                                     tabName = "tp3", span(strong(Apropos),style="color:blue"),br(),br(),Apropos1,br(),Apropos2,br(),
                                     br(),Apropos3,br(),Apropos4,br(),br(),br(),span(strong(dure),style="color:blue"),br(),strong(dure1)
                                 ),
                                 tabItem(
                                     tabName = "tp2", span(strong("Questions/Contact"),style="color:blue"),br(),br(),em(strong(question1)),
                                     mailtoR(email = "aimekoffimagloire@gmail.com",
                                              "Cliquez ICI !"
                                             
                                             
                                             
                                                 
                                             
                                             
                                             
                                             
                                             ),
                                     
                                     
                                     use_mailtoR()
                                     
                                 )
                                 
                                 
                                 
                                 
                                 
                                 
                                 
                                 
                                 
                                 
                                 
                                 
                                 
                                 
                                 
                                 
                                 
                                 
                                 
                             )),
        
        
        controlbar = dashboardControlbar(
            skin = "dark",
            controlbarMenu(
                id = "menu",
                controlbarItem(
                    h4("Pour aller plus loin") %>%
                        animateAppendNested("pulse"),hr(),
                    h2(span(strong("L'Algorithme de Kruskal﹖﹖﹖"),style="color:black")),hr(),br(),"Cet algorithme nous a permis de construire des arbres minimums couvrants dans l'élaboration de l'algorithme
                    de HDBSCAN.",hr(),br(),
                    "L'algorithme de Kruskal est un algorithme de recherche d'arbre recouvrant
                    de poids minimum (ARPM) ou arbre couvrant minimum (ACM) dans un graphe connexe non-orienté et pondéré." ,br(),
                    " Il a été conçu en 1956 par Joseph Kruskal.",hr(),br(),h4(span("Principes",style="color:black")),br(),
                    "L'algorithme construit un arbre couvrant minimum en sélectionnant des arêtes par poids croissant. Plus précisément, l'algorithme considère toutes les arêtes 
                    du graphe par poids croissant (en pratique, on trie d'abord les arêtes du graphe par poids croissant) et pour chacune d'elles, il la sélectionne si elle ne crée pas un cycle. 
                     "
                    
                ) )
        ),
        
        
        footer = dashboardFooter(
            
            left =  strong(span(h5("UNIVERSITE BRETAGNE OCCIDENTALE"),style="color:gold")) %>%
                animateAppendNested("passing",speed="slow"),
            right = strong(span(h5("Brest, 02 Septembre 2021"),style="color:gold")) %>%
                animateAppendNested("horizontal"),
            fixed = FALSE
        
        )
        
        
        
        
        
        
    )