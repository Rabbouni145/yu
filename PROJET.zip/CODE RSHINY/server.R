
server = function(input, output) {
    output$user <- renderUser({
        dashboardUser(
            name = "",
            image =phota, #"https://scontent.frns1-1.fna.fbcdn.net/v/t1.6435-9/235998770_109930034736965_8633768160003492000_n.jpg?_nc_cat=110&_nc_rgb565=1&ccb=1-5&_nc_sid=0debeb&_nc_ohc=sxTCFl28OqAAX94ZAEe&_nc_ht=scontent.frns1-1.fna&oh=a79fa297fcfa726a10f7ee787715efa2&oe=6146817C",
            title = "Aimé Magloire Ndjeng",
            subtitle = "Auteur",
            footer = p("2020/2021", class = "text-center"),
            fluidRow(
                dashboardUserItem(
                    width = 12,
                    "Etudiant en Licence 3 mathématiques Financières"
                )
            ) )
    }) 
    
    
    observeEvent(input$btn, {
        shinyalert(
            html = TRUE,
            text = tagList(
                strong(span(expli1,style="color:red")),br(),br(),em(expli2)
            )
        )
    })
    
    
      
    observeEvent(input$btn3, {
        shinyalert(confirmButtonText = "MERCI",
            html = TRUE,
            text = tagList(
                plotOutput("plot2")
            )
        )
    })
     
    
    observeEvent(input$btn7, {
      shinyalert(confirmButtonText = "MERCI",
                 html = TRUE,
                 text = tagList(
                   plotOutput("plot5")
                 )
      )
    })
    
    
   
    
    
        
   
    ## Coordonnées
    ## function coordonnée et distance
    
    Coord<-function(n){
        set.seed(1)
        return(cbind(x=runif(5,0,5)+rnorm(n,sd=0.2),
                     y=runif(5,0,5)+rnorm(n,sd=0.2))
        )
    }
  output$data1<-renderDT(data.frame(round(Coord(req(input$Nbreind)),2)))
    cl<-reactive({clusterss<-hdbscan(Coord(req(input$Nbreind)),req(input$Minps1))
                 ze1<-req(clusterss$cluster)
                 plot(Coord(req(input$Nbreind)), col=ze1)+ # la strategie pour les couleur c'est d'associer chq individu a sa class.
                   points(Coord(req(input$Nbreind))[ze1==0,], pch = 5, col = "grey")+
                   hullplot(Coord(req(input$Nbreind)),ze1,main="Formation des clusters")
    })
    
    output$plot5<-renderPlot(cl())
    
    
    
Base1<-reactive(as.matrix(dist(Coord(req(input$Nbreind)))))
output$plot2<-renderPlot(ggplot(as.data.frame(Coord(req(input$Nbreind))),aes(Coord(req(input$Nbreind))[,1],Coord(req(input$Nbreind))[,2]))+
                             geom_point()+ theme(
                               panel.background = element_rect(fill = "lightblue",
                                                               colour = "lightblue",
                                                               size = 0.5, linetype = "solid"),
                               panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                                               colour = "white"), 
                               panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                                               colour = "white")
                             )
                         
                         
                         ) 


########################################  Algorithme de PAM      ##############################################################################################################################

f<-reactive({set.seed(1)
    sample(1:req(input$Nbreind),req(input$clusters),replace = F)})# 3 devient 2

g1<-reactive(Base1()[,f()])

fonctd<-reactive({ 
    M<-Coord(input$Nbreind)
    row.names(M)=req(seq_len(input$Nbreind))
    proch<-matrix(0,ncol=req(input$clusters), nrow=nrow(g1()))# 3 devient 2
    dist1<-proch
    for(i in 1:nrow(g1())){ ####  Distance entre les medoïdes
       poss<-which(g1()[i,]==min(g1()[i,]))
        proch[i,poss]<-i
        dist1[i,poss]<-Base1()[i,f()[poss]]
    }
    diss<-sum(apply(dist1,2,sum))
  
   
    it<-0
    ite<-req(input$iteration)
    j<-1
    l<-0
    ff<-NULL
    dis<-diss+1
    mem<-matrix(0,ncol=req(input$clusters),nrow=1000) # 3 devient 2
    mem[1,]<-f()
    f2<-1:req(input$Nbreind)
    
    
    f11<-f()
    while(it<ite){
        
        
        
        if(dis>diss && length(ff)!=(length(f2)-req(input$clusters))){# 3 devient 2
            l<-l+1
            ff[l]<-f11[j]
            d<-sample(f2[-c(f11,ff)],1) # choix d'un elt objet non-methoide
            f11[j]<-d # Actualisation de la listes des methoides
            
            g11<-Base1()[,f11]
            proch<-matrix(0,ncol=req(input$clusters), nrow=nrow(g11))# 3 devient 2
            dist1<-matrix(0,ncol=req(input$clusters), nrow=nrow(g11))# 3 devient 2
            for(i in 1:nrow(g11)){ ####  Distance entre les medoïdes
                poss<-which(g11[i,]==min(g11[i,]))
                proch[i,poss]<-i
                dist1[i,poss]<-Base1()[i,f11[poss]]
            }
            dis<-sum(apply(dist1,2,sum))
            
        }
        else if(length(ff)==(length(f2)-req(input$clusters))){# 3 devient 2
            j<-j+1
            l<-0
            ff<-NULL
            mm<-mem[which(mem[,1]!=0),][nrow(mem[which(mem[,1]!=0),]),]
            mem[j,]<-mm
            f11<-mem[j,]
        }else{
            mem[j+1,]<-f11
            diss=dis
            l<-0
            dis=diss+1
            j<-j+1
        }
        
        if(j>length(f11)){
            it<-it+1
            l<-0
            dis<-diss+1
            j<-1
        }
        
        
    }
    g11<-Base1()[,f11]
    proch<-matrix(0,ncol=req(input$clusters), nrow=nrow(g11))# 3 devient 2
    dist111<-matrix(0,ncol=req(input$clusters), nrow=nrow(g11))# 3 devient 2
    for(i in 1:nrow(g11)){ ####  Distance entre les medoïdes
        poss<-which(g11[i,]==min(g11[i,]))
        proch[i,poss]<-i
        dist111[i,poss]<-Base1()[i,f11[poss]]
    }
    
    rg<-matrix(0,ncol=req(input$Nbreind),nrow=req(input$clusters) )# 3 devient 2
    for(i in 1:req(input$clusters)){# 3 devient 2
        
        rg[i,1:length(which(dist111[,i]!=0))]<-which(dist111[,i]!=0)
    }
    
    
    ze1<-NULL
    for(i in 1:req(input$Nbreind)){
        ze1[i]<-arrayInd(which(rg==i),dim(rg))[1]
    } 
    ze1[f11]<-0
    

     
    rg1<-cbind(rg,f11)
    
    
    
    a<-matrix(0,ncol=input$Nbreind, nrow=input$clusters)# 3 nombre de class
    ae<-a
    s<-a
    b<-a
    for(i in 1:input$Nbreind){
      
      classe=arrayInd(which(rg1==i),dim(rg1))[1]
      aa<-1:nrow(rg1)
      aa<-aa[-classe]
      ae[classe,i]<-sum(Base1()[,i][rg1[classe,][rg1[classe,]!=0]])/(length(which(rg1[classe,]!=0))-1)
      pm<-numeric(length(aa))
      for(j in aa){
        
        pm[j]<-sum(Base1()[i,][rg1[j,][rg1[j,]!=0]])/(length(which(rg1[j,]!=0)))
      }
      b[classe,i]<-min(pm[aa])
      s[classe,i]<-(b[classe,i]-ae[classe,i])/max(b[classe,i],ae[classe,i])
    }
    S<-apply(s,1,sum)/input$Nbreind ## la sihouette pour tous l'ensemble du cluster.
    S<-as.vector(round(sum(S),2))
    
    list(
      plot(Coord(req(input$Nbreind)), col=ze1,lwd=5,cex=7,xlab = " ",ylab = " ")+
      points(Coord(req(input$Nbreind))[ze1==0,], pch = 20, col = "grey")+
      hullplot(Coord(req(input$Nbreind)),ze1,col.main="blue",cex.main=4,main = paste(c("SILHOUETTE :")," ",S),xlab = " ",ylab = " ")+
      text(Coord(req(input$Nbreind)), row.names(M),
           cex=0.65,pos = 1,col = "red")
    
    
    )
    
   
    
    })


nex5<-eventReactive(input$lanc1,{
  fonctd()
})


output$plot11<-renderPlot(nex5()[1])

observeEvent(input$btn1, {
  shinyalert(
    html = TRUE,
    text = tagList(
      span(strong("S = Silhouette"),style="color:red"),br(),br(),"Si",br(),br(),
      span(strong(em("S:[0.71,1]")),style="color:blue"),br(),strong("Alors la Structuration est forte."),br(),br(),
      span(strong(em("S:[0.51,0.7]")),style="color:blue"),br(),strong("Alors la Structuration est raisonnable."),br(),br(),
      span(strong(em("S:[0.26,0.5]")),style="color:blue"),br(),strong("Alors la structuration est faible, sujette à caution."),br(),br(),
      span(strong(em("S:[0,0.25]")),style="color:blue"),br(),strong("Alors il n'a pas de structuration des données.")
    )
  )
})
output$textt22<-renderText({print(c("La valeur de la sihouet vaut :",nex5()[2]))})













########################################  Algorithme de DBSCAN ########################################


  eps<-function(s,y){ ##### y est la distance entre les points
    da<-NULL
    for(i in 1:(ncol(y)-1)){
      
      f<-sort(y[,i])
      f<-f[!f==0]
      da[i]<-f[s]
    }
    return(da)
    
    
  } ## cette fonction est a completer pour mettre la proposition de l'epsilon les 90%

epss<-reactive(sort(eps(4,Base1()))[(input$Nbreind)*90/100])

observeEvent(input$btn6, {
  shinyalert(
    html = TRUE,
    text = tagList(
      textOutput("textt1")
    )
  )
})


Base22<-function(x){
  return(matrix(0, ncol =x,nrow=x)) # où x represent le nombre d'individus
}


## Algo Dbscan partie II

fonct1<-reactive({ 
  
Centre1<-NULL
Base2<-Base22(input$Nbreind)
Cluster<-matrix(0,ncol=input$Nbreind,nrow=input$Nbreind)
Centre1<-NULL
  for(i in 1:input$Nbreind){
    Base2[1:length(which(Base1()[,i]<=input$Eps)),i]<-which(Base1()[,i]<=input$Eps)
    if(length(Base2[1:length(which(Base1()[,i]<=input$Eps)),i][Base2[1:length(which(Base1()[,i]<=input$Eps)),i]!=0])>=input$Minps){
      
      Centre1[i]<-i
    }
    
  }

if(length(Centre1)==0){
  Cluster[1,]<-1:input$Nbreind # alors tout le monde est valeur aberrantes. voir le Ze1
  ze1<-numeric(input$Nbreind)
}else{
Centre2<-Centre1[!is.na(Centre1)]
a1<-matrix(0,ncol =length(Centre2),nrow=length(Centre2))

  for(i in 1:length(Centre2)){
    
    z<-c(Centre2,Base2[,Centre2[i]])
    aa<-as.numeric(names(table(factor(z,levels =Centre2))[table(factor(z,levels =Centre2))==2]))
    a1[1:length(aa),i]<-aa
    
  }

d<-1
p<-1
dataa<-matrix(0,ncol=length(Centre2),nrow=length(Centre2))
dataa[1:length(Centre2),p]<-Centre2
a3<-(a1!=0)*1
a3<-apply(a3,2,sum)
if(length(which(a3==1))!=0){
  dd<-length(which(a3==1))
  Cluster[ ,1:dd]<-Base2[,Centre2[which(a3==1)]]
  Centre2<-Centre2[-which(a3==1)]
  a1<-a1[,-which(a3==1)]
  
}else(dd<-0)

i<-d  # je prend le i ieme centraux
a<-a1[,i][a1[,i]!=0][-Centre2[i]]# on prend les centraux ce trouvant dans le ieme centraux tout en supprimant le centraux auquel noous sommes. 
l<-a1[,i][a1[,i]!=0] # l permet de prendre le centraux deja selectionné
k<-length(a) 
t<-1
j<-0
d<-1
hu<-1:input$Nbreind
li<-matrix(0,ncol=length(Centre2),nrow=length(Centre2))

while(k!=0 & d!=0){
  
  
  vect<-as.vector(Base2[,a])[as.vector(Base2[,a])!=0] # selection les colonnes (Base2) des centraux se trouvant dans le centraux i(supprimé des 0).
  vect<-unique(vect)
  Vect2<-as.numeric(names(table(factor(l,levels=vect))[which(table(factor(l,levels=vect))==0)]))# Fait sortir tous les elts trouvé qui ne se trouve pas dans l où l sera mis à jour.
  
  if(sum(table(factor(Centre2,levels=Vect2)))==0){
    k<-0
    res<-sort(unique(as.vector(Base2[,l])[as.vector(Base2[,l])!=0]))  
    Cluster[c(1:length(res)),dd+1]<-res
    li[1:length(l),p]<-l
    hu[Cluster[c(1:length(res)),dd+1][which(Cluster[c(1:length(res)),dd+1]!=0)]]=dd+1
    dd<-dd+1
    
  }else{
    Vect3<-as.numeric(names(table(factor(Vect2,levels=Centre2))[which(table(factor(Vect2,levels=Centre2))==1)]))
    k<-1
    l<-c(l,Vect3) # permet de stocker les centraux deja visité(qu'on a fait sorti)
    a<-Vect3 # permet de stocker les centraux qu'on a trouvé a la ieime iteration.
    
  }
  ###  Ici c'est une condition pour voir si on continu avec la boucle sur k ou non.
  if( k==0 && sum(table(factor(as.numeric(li[ ,1:p])[-which(as.numeric(li[,1:p])==0)],levels=Centre2)))!=length(Centre2)){ 
    p<-p+1
    z<-table(factor(as.numeric(li[ ,1:(p-1)]),levels=Centre2))
    if(length(as.numeric(names(z[which(z!=0)])))==input$Nbreind){
      Cluster<-as.matrix(1:input$Nbreind)
      break
    }
    z<-as.numeric(names(z[which(z==0)]))
    d<-which(Centre2==z[1])
    
  }else if(k!=0){
    d<-d
  }else(
    d<-0
    #
  )
  
  ### 
  if(k==0 & d!=0){
    a<-a1[,d][a1[,d]!=0][-Centre2[d]]
    l<-a1[,d][a1[,d]!=0]
    k<-length(a)
  }
  
  
  
  
  
  
  
  
  
  
  
  }


ze1<-NULL
for(i in 1:input$Nbreind){
  ze1[i]<-arrayInd(which(Cluster==i),dim(Cluster))[2]
}  
ze1[is.na(ze1)]<-0


}



plot(Coord(input$Nbreind), col=ze1)+ # la strategie pour les couleur c'est d'associer chq individu a sa class.
points(Coord(input$Nbreind)[ze1==0,], pch = 5, col = "grey")+
hullplot(Coord(input$Nbreind),ze1,main="Formation de Clusters")
















})




poo<-reactive({
  re<-dbscan(Coord(input$Nbreind),input$Eps,input$Minps)
  plot(Coord(input$Nbreind), col=re$cluster)
  points(Coord(input$Nbreind)[re$cluster==0,], pch = 5, col = "grey")
  hullplot(Coord(input$Nbreind),re$cluster)
  
  
})







nex7<-eventReactive(input$lanc2,{
  fonct1()
})






output$plot3<-renderPlot(nex7())

output$textt1<-renderText({print(c("Minp= 5,"," ", "Epsilon =",round(epss(),2)))})

  






########################################  Algorithme de Hdbscan      ####




Dist<-reactive(matrix(0,ncol=input$Nbreind,nrow=input$Nbreind))
g<-reactive(1:input$Nbreind)



frr<-reactive({  
  Distt<-Dist()
  gg<-g()
  
  
for(i in 1:input$Nbreind){
  
  i2<-sort(Base1()[,i])
  for(j in gg[-c(1:i)]){ 
    i1<-sort(Base1()[,j])
    Distt[j,i]<-max(i2[input$kdist+1],i1[input$kdist+1],Base1()[j,i])
    Distt
    
  }
}

  
Da<-order(Distt)[(cumsum(1:input$Nbreind)[input$Nbreind]+1):(input$Nbreind*input$Nbreind)] # 56:100 devient  cumsum(1:n)[n]+1
l<-arrayInd(which(Distt==Distt[Da[1]]),dim(Distt))
Distn<-matrix(0,ncol=ncol(Distt),nrow=nrow(Distt))
Distn[min(arrayInd(which(Distt==Distt[Da[1]]),dim(Distt)))
      ,max(arrayInd(which(Distt==Distt[Da[1]]),dim(Distt)))]<-Distt[max(arrayInd(which(Distt==Distt[Da[1]]),dim(Distt))),
                                                                min(arrayInd(which(Distt==Distt[Da[1]]),dim(Distt)))]

Distn[min(arrayInd(which(Distt==Distt[Da[2]]),dim(Distt)))
      ,max(arrayInd(which(Distt==Distt[Da[2]]),dim(Distt)))]<-Distt[max(arrayInd(which(Distt==Distt[Da[2]]),dim(Distt))),
                                                                min(arrayInd(which(Distt==Distt[Da[2]]),dim(Distt)))]
for(i in 1:(length(Da)-1)){ 
  if(Distt[Da[i]]!=Distt[Da[i+1]]){ 
    l<-rbind(l,arrayInd(which(Distt==Distt[Da[i+1]]),dim(Distt)))
    for(j in 1:nrow(arrayInd(which(Distt==Distt[Da[i+1]]),dim(Distt)))){ 
      f<-arrayInd(which(Distt==Distt[Da[i+1]]),dim(Distt))[j,]
      Distn[f[1],f[2]]<-Distt[max(f),min(f)]
    }
    
  }
  
  
}

M<-numeric(input$Nbreind) # 10 devient n
M1<-matrix(0,ncol=ncol(l),nrow=nrow(l))
j=0
j1<-0
mp<-matrix(0,ncol=4000,nrow=4000) # 40,45 devient n
Distt<-Distt+t(Distt)
myg1<-graph.adjacency(Distn,mode = "undirected",weighted = TRUE)
PO<-matrix(0,ncol=4000,nrow=4000) # 40 devient n
Epsilon<-matrix(0,input$Nbreind)
Epsilon2<-matrix(0,input$Nbreind)
Epsiln<-matrix(0,input$Nbreind)
poids<-numeric(4000)# 40 devient n




poa<-for(i in order(E(myg1)$weight)){
  
  v1<-as.numeric(get.edgelist(myg1)[i,1]);
  v2<-as.numeric(get.edgelist(myg1)[i,2]);
  if(M[v1]==0 && M[v2]==0){
    j=j+1
    j1<-j1+1
    Epsilon[v1]<-E(myg1)$weight[i]
    Epsilon[v2]<-E(myg1)$weight[i]
    M1[j,]=c(v1,v2)
    PO[j,1:2]<-c(v1,v2)
    poids[j]<-(1/E(myg1)$weight[i])
    M[v1]=j1;M[v2]=j1
    mp[v1,v2]<-Distt[v1,v2]
    mp[v2,v1]<-Distt[v1,v2] 
    # stock la distance des news
    E(myg1)[i]$color="red"
    plot.igraph(myg1,layout=Coord(input$Nbreind),main="arbre couvrant minimum")
    Sys.sleep(0.1)
    if(length(unique(M))==1){break}
    
  }else if(M[v2]==0 || M[v1]==0){
    j=j+1
    
    M1[j,]=c(v1,v2)
    mp[v1,v2]<-Distt[v1,v2]
    mp[v2,v1]<-Distt[v1,v2] 
    
    if(M[v2]==0){
      
      Epsilon[v2]<-E(myg1)$weight[i]
      po1<-arrayInd(which(PO==v1),dim(PO))
      PO[j,1:(length(PO[po1[nrow(po1),1],][PO[po1[nrow(po1),1],]!=0])+1)]<-c(PO[po1[nrow(po1),1],][PO[po1[nrow(po1),1],]!=0],v2)
      poids[j]<-(1/E(myg1)$weight[i])
      M[v2]=M[v1]
      E(myg1)[i]$color="red"
      plot.igraph(myg1,layout=Coord(input$Nbreind),main="arbre couvrant minimum")
      Sys.sleep(0.1)
      if(length(unique(M))==1){  break}
      
    }else{
      Epsilon[v1]<-E(myg1)$weight[i]
      po1<-arrayInd(which(PO==v2),dim(PO))
      PO[j,1:(length(PO[po1[nrow(po1),1],][PO[po1[nrow(po1),1],]!=0])+1)]<-c(PO[po1[nrow(po1),1],][PO[po1[nrow(po1),1],]!=0],v1)
      poids[j]<-(1/E(myg1)$weight[i])
      M[v1]=M[v2]
      E(myg1)[i]$color="red"
      plot.igraph(myg1,layout=Coord(input$Nbreind),main="arbre couvrant minimum")
      Sys.sleep(0.1)
      if(length(unique(M))==1){  break}
    }
    
    
    
  }else{  
    if(M[v2]==M[v1]){
      M1[i,]=0
      
      
      
    }else{ 
      j=j+1
      po1<-arrayInd(which(PO==v2),dim(PO))
      po11<-PO[po1[nrow(po1),1],][PO[po1[nrow(po1),1],]!=0]
      po2<-arrayInd(which(PO==v1),dim(PO))
      po22<-PO[po2[nrow(po2),1],][PO[po2[nrow(po2),1],]!=0]
      PO[j,1:length(c(po11,po22))]<-c(po11,po22)
      poids[j]<-(1/E(myg1)$weight[i])
      M1[j,]=c(v1,v2)
      Epsilon2[v2]<-Distt[v1,v2]
      M[which(M==M[v2])]=M[v1]
      mp[v1,v2]<-Distt[v1,v2]
      mp[v2,v1]<-Distt[v1,v2] 
      E(myg1)[i]$color="red"
      plot.igraph(myg1,layout=Coord(input$Nbreind),main="Kruskal")
      Sys.sleep(0.1)
      if(length(unique(M))==1){  break}
      
    }
    
  }
  
  if(length(unique(M))==1){  break}
  
}



POO<-PO[PO[,1]!=0,]

poa



})


nex6<-eventReactive(input$lanc3,{
  frr()
})

output$plot4<-renderPlot(nex6())





######################################### CALCUL DES PRIMES ###########################################



E<-function(x,n,i) (Datatable[x+n+1,1]/Datatable[x+1,1])/(1+i)^n
E2<-function(x,y,n,i)(Datatable[x+n+1,1]/Datatable[x+1,1])*(Datatable[y+1+n,2]/Datatable[y+1,2])/(1+i)^n 
EF<-function(x,n,i) (Datatable[x+n+1,2]/Datatable[x+1,2])/(1+i)^n
# Annuité Viagere annuels echus immédiate et illimité

a_x<-function(x,i) sum(E(x,1:(111-x),i))
a_y<-function(y,i) sum(EF(y,1:(113-y),i))
a_xy<-function(x,y,i) sum(E2(x,y,1:min((111-x),111-y),i))

A_ax<-function(x,i) sum( (( (Datatable[(x+1):111,1]-Datatable[(x+2):112,1])/Datatable[x+1,1]))/(1+i)^((0:110)+1/2)) 
A_ay<-function(y,i) sum( ((Datatable[(y+1):113,2]/Datatable[y+1,2])-(Datatable[(y+2):114,2]/Datatable[y+1,2]))/(1+i)^((0:112)+1/2)) 

A_axn<-function(x,n,i) sum( ((Datatable[(x+1):(x+n),1]/Datatable[x+1,1])-(Datatable[(x+2):(x+n+1),1]/Datatable[x+1,1]))/(1+i)^((0:n-1)+1/2)) 
A_ayn<-function(y,n,i) sum( ((Datatable[(y+1):(y+n),2]/Datatable[y+1,2])-(Datatable[(y+2):(y+n+1),2]/Datatable[y+1,2]))/(1+i)^((0:n-1)+1/2)) 

Prime_DECES<-reactive({A_ax(input$Age_homme,0.02)/a_xn(input$Age_homme,30,0.02)})



## AVANCE

a_xa<-function(x,i) sum(E(x,1:(110-x),i))
a_ya<-function(y,i) sum(EF(y,1:(112-y),i))
a_xya<-function(x,y,i) sum(E2(x,y,1:min((110-x),110-y),i))


# Annuité Viagère à termes annuels Immédiate et temporelle de n années echu
a_xn<-function(x,n,i) sum(E(x,1:n,i))
a_yn<-function(y,n,i) sum(EF(y,1:n,i))

# annuité viagére AVANCE
a_xan<-function(x,n,i) sum(E(x,1:(n-1),i))
a_yan<-function(y,n,i) sum(EF(y,1:(n-1),i))


# Annuité Viagére à termes annuels echus differées de k années et illimitées
k_ax<-reactive({ E(input$Age_homme,input$annee_contrat1,0.01)*a_x(input$Age_homme+input$annee_contrat1,0.01)})

k_ay<-reactive({ E(input$C3,input$annee_contrat1,0.01)*a_x(input$Age_homme+input$annee_contrat1,0.01)})

## Annuité viagere a termes avance différé k année et illimité
k_axa<-reactive({ E(input$Age_homme,input$annee_contrat1-1,0.01)*a_xa(input$Age_homme+input$annee_contrat1,0.01)})

k_aya<-reactive({ E(input$C3,input$annee_contrat1-1,0.01)*a_x(input$Age_homme+input$annee_contrat1,0.01)})





# Annuité viagère à termes annuels echus différés de k années et temporaire de n années

k_axn<-reactive({E(input$Age_homme,input$annee_contrat2,0.01)*a_xn(input$Age_homme+input$annee_contrat2,input$duree_contrat2,0.01)})

## Annuité viagere à termes annuels et avance differes de k années et temporaire de n années

k_axan<-reactive({E(input$Age_homme,input$annee_contrat2-1,0.01)*a_xan(input$Age_homme+input$annee_contrat2,input$duree_contrat2,0.01)})





## ANNUITE VIAGERES FRACTIONNEES


# Annuité Viagere (m) echus immédiate et illimité

a_xm<-function(x,i,m) a_x(x,i)+((m-1)/(2*m))
a_ym<-function(y,i,m) a_y(y,i)+(m-1)/(2*m)
# Annuité Viagère à termes fractionnés échus immediates et temporaires de n années
am_xn<-function(x,n,i,m) a_xn(x,n,i)+((m-1)*(1-E(x,n,i)))/(2*m)
am_yn<-function(y,n,i,m) a_yn(y,n,i)+(m-1)*(1-EF(y,n,i))/(2*m)

# Annuité Viagère à termes annuels Immédiate et temporelle de n années

k_axm<-function(x,k,m) E(x,k,0.01)*a_xm(x+k,0.01,m) # 
k_aym<-function(y,k,m) EF(y,k,0.01)*a_ym(y+k,0.01,m) # 

# Annuité viagère à termes frationnés échus différés de k années pendant n années
k_am_xn<-function(x,k,n,m) E(x,k,0.01)*am_xn(x+k,n,0.01,m)
k_am_yn<-function(y,k,n,m) EF(y,k,0.01)*am_yn(y+k,n,0.01,m)




######################################################## A VOIR ########################################################
## Rentes
# Rente de reversion
R_r<-reactive({ a_xm(input$Age_homme,0.01,as.numeric(input$Payable))+(input$taux_reversion/100)*(a_x(input$Age_homme,0.01)-a_xy(input$Age_homme,input$C3,0.01))})

# rente de survie
R_s<-reactive({ a_y(input$C3,0.01)-a_xy(input$Age_homme,input$C3,0.01)})


# Rente jumelée

R_j<-reactive({a_y(input$C3,0.01)+(as.numeric(input$Payable)-1)/(2*as.numeric(input$Payable))})

# Rente deux tetes
R_2t<-reactive({ a_x(input$Age_homme,0.01)+a_y(input$C3,0.01)-a_xy(input$Age_homme,input$C3,0.01)+(as.numeric(input$Payable)-1)/(2*as.numeric(input$Payable))})

#######################################################################################################################





################# CALCULS DES PRIMES (1,0) #############################






# DECES VIAGERE
PRIME_DECESV1<-reactive({input$MontantCd*A_ax(input$Age_homme,0.01)/(a_xa(input$Age_homme,0.01)*(1-0.1))}) ## prime pour un homme
PRIME_DECESV2<-reactive({input$MontantCd*A_ay(input$Age_homme,0.01)/(a_ya(input$Age_homme,0.01)*(1-0.1))}) ## prime pour une femme

# DECES TEMPORAIRE

PRIME_DECEST1<-reactive({input$MontantCd1*A_ax(input$Age_homme,0.01)/(a_xan(input$Age_homme,input$Duréé_Contrat,0.01)*(1-0.1))}) ## prime pour un homme
PRIME_DECEST2<-reactive({input$MontantCd1*A_ax(input$Age_homme,0.01)/(a_yan(input$Age_homme,input$Duréé_Contrat,0.01)*(1-0.1))}) ## prime pour une femme

Contrat3<-reactive({ 
  if(input$Capital_dècès=='2' && input$Sexe=='1'){
    PRIME_DECESV1()
  }else if(input$Capital_dècès=='2' && input$Sexe=='2'){
    PRIME_DECESV2()
  }else if(input$Capital_dècès=='1' && input$Sexe=='1'){
    PRIME_DECEST1()
  }else(PRIME_DECEST2())
  
}) ## Contrat ==3



###########################################################################








PRIME_DECESN<-reactive({round((1+0.1)*input$MontnatDA22*(1-(Datatable[input$Age_homme+1,1]/Datatable[input$Age_homme,1]))*a_ym(input$C3,0.003,1)/(1-0.01) ,4)})


################ Prime rente conjoint viagere ou temporaire
PRIME_RENTE_VIAGERE<-reactive({round((1+0.1)*input$MontnatDA22*(1-(Datatable[input$Age_homme+1,1]/Datatable[input$Age_homme,1]))*a_ym(input$C3,0.003,1)/(1-0.01) ,4)}) ## j'ai pris un homme et une femme beneficiaire
PRIME_RENTE_Differe<-reactive({ round((1+0.1)*input$MontnatDA22*(1-(Datatable[input$Age_homme+1,1]/Datatable[input$Age_homme,1]))*am_yn(input$C3,input$Durée_M1,0.003,1)/(1-0.01), 4)})


############## PRIME EPARGNE ##############################


k_am_xn1<-reactive({E(input$Age_homme,input$annee_D2,0.01)*am_xn(input$Age_homme+input$annee_D2,input$duree_D1,0.01,as.numeric(input$Montant_D4))})
P_EP<-reactive({round((1-0.01)*input$Montant_D4*am_xn(input$Age_homme,input$annee_D1,0.01,as.numeric(input$selectC))/a_xm(input$Age_homme,0.01,as.numeric(input$selectC)) ,4)}) ## Epargne pour k et remboursement viagère.
P_EP20<-reactive({ round((1-0.01)*input$Montant_D4*am_xn(input$Age_homme,input$annee_D2,0.01,as.numeric(input$selectC))/k_am_xn1() ,4)}) ## Epargne pour k cotisation et remboursement pendant n année

k_am_xn2<-reactive({EF(input$Age_homme,input$annee_D2,0.01)*am_yn(input$Age_homme+input$annee_D2,input$duree_D1,0.01,as.numeric(input$Montant_D4))})
P_EP3<-reactive({round( (1-0.01)*input$Montant_D4*am_yn(input$Age_homme,input$annee_D1,0.01,as.numeric(input$selectC))/a_ym(input$Age_homme,0.01,as.numeric(input$selectC)),4) }) ## Epargne pour k et remboursement viagère.
P_EP22<-reactive({round((1-0.01)*input$Montant_D4*am_yn(input$Age_homme,input$annee_D2,0.01,as.numeric(input$selectC))/k_am_xn2() ,4) }) ## Epargne pour k cotisation et remboursement pendant n année




Resultat10<-reactive({
  if( input$Rente=='1' && input$MontnatDA22 !="" && input$C3 !=""){
    PRIME_RENTE_VIAGERE()
  }else if(input$Rente=='2' && input$Durée_M1 !="" && input$MontnatDA22 !="" && input$C3 !=""){
    PRIME_RENTE_Differe()
  }else(" VOUS AVEZ OUBLIE UN PARAMETRE MERCIII.")
}) 

PRIME10<-reactive({
  if(input$Sexe=='1' && input$selectD=='3'){
    P_EP()
  }else if(input$Sexe=='1' && input$selectD=='4'){P_EP20()}
  else if(input$Sexe=='2' && input$selectD=='3'){P_EP3()}
  else if(input$Sexe=='2' && input$selectD=='4'){
    P_EP22()
  }else(0)
  
}) ### HOMME Epargne;  contrat vaut 2


# final 1
RESULTATHF<-reactive({
  if(input$Contrats=='1'){Resultat10()}else(PRIME10())
})


















################# CALCULS DES PRIMES (1,1) #############################




################ Prime rente conjoint viagere ou temporaire


PRIME_RENTE_VIAGERE2<-reactive({round((1+0.01)*input$MontnatDA22*(1-(Datatable[input$Age_homme+1,1]/Datatable[input$Age_homme,1]))*a_xm(input$C3,0.01,4)/(1-0.01),4)}) ## j'ai pris un homme et une femme beneficiaire
PRIME_RENTE_Differe2<-reactive({ round((1+0.01)*input$MontnatDA22*(1-(Datatable[input$Age_homme+1,1]/Datatable[input$Age_homme,1]))*am_xn(input$C3,input$Durée_M1,0.01,4)/(1-0.01) ,4)})


############## PRIME EPARGNE ##############################


k_am_xn1<-reactive({E(input$Age_homme,input$annee_D2,0.01)*am_xn(input$Age_homme+input$annee_D2,input$duree_D1,0.01,as.numeric(input$Montant_D4))})
P_EP2<-reactive({round((1-0.01)*input$Montant_D4*am_xn(input$Age_homme,input$annee_D1,0.01,as.numeric(input$selectC))/a_xm(input$Age_homme,0.01,as.numeric(input$selectC)) ,4)}) ## Epargne pour k et remboursement viagère.
P_EP21<-reactive({round( (1-0.01)*input$Montant_D4*am_xn(input$Age_homme,input$annee_D2,0.01,as.numeric(input$selectC))/k_am_xn1() ,4) }) ## Epargne pour k cotisation et remboursement pendant n année








Resultat11<-reactive({
  if( input$Rente=='1' && input$MontnatDA22 !="" && input$C3 !=""){
    PRIME_RENTE_VIAGERE2()
  }else if(input$Rente=='2' && input$Durée_M1 !="" && input$MontnatDA22 !="" && input$C3 !=""){
    PRIME_RENTE_Differe2()
  }else(" VOUS AVEZ OUBLIE UN PARAMETRE MERCIII.")
}) 

PRIME11<-reactive({
  if(input$Montant_D4 !="" && input$annee_D1 !=""){
    P_EP2()
  }else if(input$annee_D2 !="" && input$duree_D1 !="" && input$Montant_D4 !=""){
    P_EP21()
  }
  
})


# final 2
RESULTATHH<-reactive({
  if(input$Contrats=='1'){Resultat11()}else(PRIME11())
})






######################################################## (0,1) ############################################################





################ Prime rente conjoint viagere ou temporaire #################


PRIME_RENTE_VIAGERE3<-reactive({ round((1+0.01)*input$MontnatDA22*(1-(Datatable[input$Age_homme+1,2]/Datatable[input$Age_homme,2]))*a_xm(input$C3,0.01,4)/(1-0.01) ,4) }) ## j'ai pris un homme et une femme beneficiaire
PRIME_RENTE_Differe3<-reactive({round((1+0.01)*input$MontnatDA22*(1-(Datatable[input$Age_homme+1,2]/Datatable[input$Age_homme,2]))*am_xn(input$C3,input$Durée_M1,0.01,4)/(1-0.01),4) })


############## PRIME EPARGNE ##############################


k_am_xn2<-reactive({EF(input$Age_homme,input$annee_D2,0.01)*am_yn(input$Age_homme+input$annee_D2,input$duree_D1,0.01,as.numeric(input$Montant_D4))})
P_EP3<-reactive({round( (1-0.01)*input$Montant_D4*am_yn(input$Age_homme,input$annee_D1,0.01,as.numeric(input$selectC))/a_ym(input$Age_homme,0.01,as.numeric(input$selectC)),4) }) ## Epargne pour k et remboursement viagère.
P_EP22<-reactive({round((1-0.01)*input$Montant_D4*am_yn(input$Age_homme,input$annee_D2,0.01,as.numeric(input$selectC))/k_am_xn2() ,4) }) ## Epargne pour k cotisation et remboursement pendant n année








Resultat01<-reactive({
  if( input$Rente=='1' && input$MontnatDA22 !="" && input$C3 !=""){
    PRIME_RENTE_VIAGERE3()
  }else if(input$Rente=='2' && input$Durée_M1 !="" && input$MontnatDA22 !="" && input$C3 !=""){
    PRIME_RENTE_Differe3()
  }else(" VOUS AVEZ OUBLIE UN PARAMETRE MERCIII.")
}) 

PRIME01<-reactive({
  if(input$Montant_D4 !="" && input$annee_D1 !=""){
    P_EP3()
  }else if(input$annee_D2 !="" && input$duree_D1 !="" && input$Montant_D4 !=""){
    P_EP22()
  }
  
})


# final 3
RESULTATFH<-reactive({
  if(input$Contrats=='1'){Resultat01()}else(PRIME01())
})











##################################################  (0,0) ##################################################





################ Prime rente conjoint viagere ou temporaire ####################################


PRIME_RENTE_VIAGERE4<-reactive({round((1+0.01)*input$MontnatDA22*(1-(Datatable[input$Age_homme+1,2]/Datatable[input$Age_homme,2]))*a_ym(input$C3,0.01,4)/(1-0.01),4)}) ## j'ai pris un homme et une femme beneficiaire
PRIME_RENTE_Differe4<-reactive({round((1+0.01)*input$MontnatDA22*(1-(Datatable[input$Age_homme+1,2]/Datatable[input$Age_homme,2]))*am_yn(input$C3,input$Durée_M1,0.01,4)/(1-0.01) ,4)})


############## PRIME EPARGNE ##############################


k_am_xn2<-reactive({EF(input$Age_homme,input$annee_D2,0.01)*am_yn(input$Age_homme+input$annee_D2,input$duree_D1,0.01,as.numeric(input$Montant_D4))})
P_EP4<-reactive({round( (1-0.01)*input$Montant_D4*am_yn(input$Age_homme,input$annee_D1,0.01,as.numeric(input$selectC))/a_ym(input$Age_homme,0.01,as.numeric(input$selectC)),4) }) ## Epargne pour k et remboursement viagère.
P_EP23<-reactive({ round((1-0.01)*input$Montant_D4*am_yn(input$Age_homme,input$annee_D2,0.01,as.numeric(input$selectC))/k_am_xn2() ,4) }) ## Epargne pour k cotisation et remboursement pendant n année





Resultat00<-reactive({
  if( input$Rente=='1' && input$MontnatDA22 !="" && input$C3 !=""){
    PRIME_RENTE_VIAGERE4()
  }else if(input$Rente=='2' && input$Durée_M1 !="" && input$MontnatDA22 !="" && input$C3 !=""){
    PRIME_RENTE_Differe4()
  }else(" VOUS AVEZ OUBLIE UN PARAMETRE MERCIII.")
}) 

PRIME00<-reactive({
  if(input$Montant_D4 !="" && input$annee_D1 !=""){
    P_EP4()
  }else if(input$annee_D2 !="" && input$duree_D1 !="" && input$Montant_D4 !=""){
    P_EP23()
  }
  
})


# final 4
RESULTATFF<-reactive({
  if(input$Contrats=='1'){Resultat00()}else(PRIME00())
})





######################################################



PRIME_FINALE<-reactive({
  if(input$Sexe=='1' && input$Sexe_Beneficiaire=='2')
    {Resultat10()
    
    }
  else if(input$Sexe=='1' && input$Sexe_Beneficiaire=="1"){Resultat11()
   }
  else if(input$Sexe=='2' && input$Sexe_Beneficiaire=="1"){Resultat01()
    }else if(input$Sexe=='2' && input$Sexe_Beneficiaire=="2"){Resultat00()}else(0)
}) ## CONTRAT 1


PRIME_FINAL_FINAL<-reactive({
  if(input$Contrats=='1'){PRIME_FINALE()
  }else if(input$Contrats=='2'){PRIME10()}
  else(paste("Engagement assuré :",round(Contrat3(),4)))
})



DFF<-eventReactive(req(input$PRIME_CALCUL),{
  PRIME_FINAL_FINAL()
})

output$value <- renderPrint({paste(DFF(),"$")})
observeEvent(input$DESCRIPTION01,{
  shinyalert(
    html = TRUE,
    text = tagList(h4("Description du contrat"),br(),h5("Engagement assureur"),
                   "L'assurance s'engage à verser une prime unique brute de",input$MontantCd," $ ","à Mr/Md ", input$A1, input$A2,"s'il décéde.",
                   br(),br(),
                   h5("Engagement assuré"),br(),"Je soussigné Mr/Md ",input$A1, input$A2,"à avoir souscrit une assurance vie
                   auprès de Blackpearl le 02/02/2023. Je m'engage à vercer une prime annuelle de ",round(Contrat3(),4)," $.",
                   br(),br(), 
                   h5("Informations Souscripteur"),br(),
                   "Nom et prenom Souscripteur :", input$A1, input$A2,br(),
                   "Age du souscripteur :", input$Age_homme, "ans", br(),
                   "Lieu de residence du souscripteur :", input$B3, br()
    )
    
  )
})

observeEvent(input$DESCRIPTION0,{
  shinyalert(
    html = TRUE,
    text = tagList(h4("Description du contrat"),br(),h5("Engagement assureur"),
                   "L'assurance s'engage à verser une prime unique brute de",input$MontantCd1," $ ","à Mr/Md ", input$A1, input$A2,"s'il décéde dans les ",input$Duréé_Contrat," prochaines années suivant la souscription",
                   br(),br(),
                   h5("Engagement assuré"),br(),"Je soussigné Mr/Md ",input$A1, input$A2,"à avoir souscrit une assurance vie
                   auprès de Blackpearl le 02/02/2023. Je m'engage à vercer une prime annuelle de ",round(Contrat3(),4)," $.",
                   br(),br(), 
                   h5("Informations Souscripteur"),br(),
                   "Nom et prenom Souscripteur :", input$A1, input$A2,br(),
                   "Age du souscripteur :", input$Age_homme, "ans", br(),
                   "Lieu de residence du souscripteur :", input$B3, br()
    )
    
  )
})


observeEvent(input$DESCRIPTION1,{
  shinyalert(
    html = TRUE,
    text = tagList(h4("Description du contrat"),br(),h5("Engagement assureur"),
                   "L'assurance s'engage à verser une prime annuelle viagère", input$MontnatDA22," $ ","à Mr/Md ",
                    input$C1, input$C2, "si Mr/Md ",input$A1, input$A2," décede dans l'année.",
                   br(),br(),
                   h5("Engagement assuré"),br(),"Je soussigné Mr/Md ",input$A1, input$A2,"à avoir souscrit à une assurance vie
                   auprès de Blackpearl le 02/02/2023. Je m'engage à vercer une prime unique de ",PRIME_FINALE()," $", " lors de la scouscription du contrat.",
                   br(),br(), 
                   h5("Informations Souscripteur et Beneficiaire"),br(),
                   "Nom et prenom Souscripteur :", input$A1, input$A2,br(),
                   "Nom et prenom Beneficiaire :", input$C1, input$C2, br(),
                   "Age du souscripteur :", input$Age_homme, "ans", br(),
                   "Age du beneficiaire :", input$C3, "ans",br(),
                   "Lieu de residence du souscripteur :", input$B3, br(),
                   "Lieu de residence du Beneficiaire :", input$C4
                   )
    
  )
})

observeEvent(input$DESCRIPTION2,{
  shinyalert(
    html = TRUE,
    text = tagList(h4("Description du contrat"),br(),h5("Engagement assureur"),
                   "L'assurance s'engage à verser une prime annuelle de ",input$MontnatDA22," $ ","pendant ",input$Durée_M1 ,"ans","à Mr/Md ",
                   input$C1, input$C2, "si Mr/Md ",input$A1, input$A2," décéde dans l'année.",
                   br(),br(),
                   h5("Engagement assuré"),br(),"Je soussigné Mr/Md ",input$A1, input$A2,"à avoir souscrit à une assurance vie
                   auprès de Blackpearl le 02/02/2023. Je m'engage à vercer une prime unique de ",PRIME_FINALE()," $", " lors de la scouscription du contrat.",
                   br(),br(), 
                   h5("Informations Souscripteur et Beneficiaire"),br(),
                   "Nom et prenom Souscripteur :", input$A1, input$A2,br(),
                   "Nom et prenom Beneficiaire :", input$C1, input$C2, br(),
                   "Age du souscripteur :", input$Age_homme, "ans", br(),
                   "Age du beneficiaire :", input$C3, "ans",br(),
                   "Lieu de residence du souscripteur :", input$B3, br(),
                   "Lieu de residence du Beneficiaire :", input$C4
    )
    
  )
})



observeEvent(input$DESCRIPTION03,{
  shinyalert(
    html = TRUE,
    text = tagList(h4("Description du contrat"),br(),h5("Engagement assureur"),
                   "L'assurance s'engage à verser une prime annuelle viagère de ",PRIME10()," $ "," à Mr/Md ",input$A1, input$A2,".",
                   br(),br(),
                   h5("Engagement assuré"),br(),"Je soussigné Mr/Md ",input$A1, input$A2,"à avoir souscrit à une assurance vie du type contrat plurannuelle
                   auprès de Blackpearl le 02/02/2023. Je m'engage à vercer une cotisation de  ", input$Montant_D4 ," $", " pendant",input$annee_D1, "ans",
                   br(),br(), 
                   h5("Informations Souscripteur "),br(),
                   "Nom et prenom Souscripteur :", input$A1, input$A2, br(),
                   "Age du souscripteur :", input$Age_homme, "ans", br(),
                   "Lieu de residence du souscripteur :", input$B3
    )
    
  )
})



observeEvent(input$DESCRIPTION04,{
  shinyalert(
    html = TRUE,
    text = tagList(h4("Description du contrat"),br(),h5("Engagement assureur"),
                   "L'assurance s'engage à verser une prime annuelle de ",PRIME10()," $ ","pendant ",input$duree_D1," ans"," à Mr/Md ",input$A1, input$A2," à compter de ",input$annee_D2,".",
                   br(),br(),
                   h5("Engagement assuré"),br(),"Je soussigné Mr/Md ",input$A1, input$A2,"à avoir souscrit à une assurance vie du type contrat plurannuelle
                   auprès de Blackpearl le 02/02/2023. Je m'engage à vercer une cotisation de  ", input$Montant_D4 ," $", " pendant ",input$annee_D2, " ans",
                   br(),br(), 
                   h5("Informations Souscripteur "),br(),
                   "Nom et prenom Souscripteur :", input$A1, input$A2, br(),
                   "Age du souscripteur :", input$Age_homme, "ans", br(),
                   "Lieu de residence du souscripteur :", input$B3
    )
    
  )
})

observeEvent(input$INFO,{
  shinyalert(
    html = TRUE,
    text = tagList(span(strong(h3("Prévoyance décès :")),style="color:blue") ,br(),br(),
                   h4(" Ce type de contrat, l’engagement est annuel et il n’y a donc pas de provision mathématique
mais des PSAP/PSI. Toutefois, lorsqu’un sinistre est survenu et que celui-ci est de type rente, l’organisme d’assurance
doit nécessairement calculer des provisions mathématiques de rentes. Dans notre application nous avons utilisé (Rente conjoint et Rente temporaire)."), hr(),hr(),br(),
                   span(strong(h3("Contrat PLuriannuel :")),style="color:blue"),br(),br(),
                   h4(" C'est un contrat lié à des risques qui sont plus longs, l’organisme d’assurance doit provisionner en fonction de ces
                   engagements futurs desquels il soustrait les engagements futurs de l’assuré. Dans ce cas-là, on parle de provisions
                   mathématiques."), hr(),hr(),br(),
                   span(strong(h3(" Assurance vie :")),style="color:blue"),hr(),hr(),br(),h4(" C'est un contrat lié à des risques qui sont plus longs, l’organisme d’assurance doit provisionner en fonction de ces
                   engagements futurs desquels il soustrait les engagements futurs de l’assuré. Dans ce cas-là, on parle de provisions
                   mathématiques.")
                   
                   
                   
    )
    
  )
})


observeEvent(input$PROVISION,{
  shinyalert(
    html = TRUE,
    text = tagList(span(strong("Cette partie est en cours , j'ai construit les fonctions pour le calcul des provisions, il reste maintenant à les implémenter dans cette application."),style="color:blue"),hr(),hr(),br(), 
                   " On appelle Provision Mathématique le total des réserves calculées pour chaque contrat en cours, à la 
clôture de chaque exercice comptable de l'assureur. ", br(),"Alors la provision mathématique est calculée par différence entre les engagements de l’assureur et ceux de
l’assuré :" ,hr(),br(),span(strong(" PM_k=  Engagement Assureur en k - Engagement Assuré en k.",style="color:red")), br(),hr(),
                   "De plus, j'ai utilisé deux methodes de calcul pour le provisionnement :",br(),br(),
                   span(strong("La méthode prospective et par la méthode rétrospective."),style="color:red"),br(),br(),hr(),
                   span(strong("A BIENTÔT...."),style="color:blue")
                   
                   
                   
    )
    
  )
})



observeEvent(input$Info_charg,{
  shinyalert(
    html = TRUE,
    text = tagList("Pour l'application j'ai fixé le taux de mes chargements, averrages et taux techniques.
                   ", hr(),br(),"J'ai pris un taux technique fixe de 1% puis j'ai fixé tous mes chargements à 1%."
                   
                   
                   
    )
    
  )
})





 





















Hommes=c(100000,
         99511,
         99473,
         99446,
         99424,
         99406,
         99390,
         99376,
         99363,
         99350,
         99338,
         99325,
         99312,
         99296,
         99276,
         99250,
         99213,
         99163,
         99097,
         99015,
         98921,
         98820,
         98716,
         98612,
         98509,
         98406,
         98303,
         98198,
         98091,
         97982,
         97870,
         97756,
         97639,
         97517,
         97388,
         97249,
         97100,
         96939,
         96765,
         96576,
         96369,
         96141,
         95887,
         95606,
         95295,
         94952,
         94575,
         94164,
         93720,
         93244,
         92736,
         92196,
         91621,
         91009,
         90358,
         89665,
         88929,
         88151,
         87329,
         86460,
         85538,
         84558,
         83514,
         82399,
         81206,
         79926,
         78552,
         77078,
         75501,
         73816,
         72019,
         70105,
         68070,
         65914,
         63637,
         61239,
         58718,
         56072,
         53303,
         50411,
         47390,
         44234,
         40946,
         37546,
         34072,
         30575,
         27104,
         23707,
         20435,
         17338,
         14464,
         11852,
         9526,
         7498,
         5769,
         4331,
         3166,
         2249,
         1549,
         1032,
         663,
         410,
         244,
         139,
         75,
         39,
         19,
         9,
         4,
         2,
         1,
         0,
         0
         ,0)



Femmes<-c( 
  100000,
  99616,
  99583,
  99562,
  99545,
  99531,
  99519,
  99508,
  99498,
  99488,
  99478,
  99467,
  99456,
  99444,
  99431,
  99415,
  99395,
  99371,
  99342,
  99309,
  99274,
  99239,
  99205,
  99171,
  99137,
  99103,
  99068,
  99033,
  98997,
  98960,
  98921,
  98879,
  98833,
  98782,
  98725,
  98662,
  98593,
  98518,
  98435,
  98343,
  98242,
  98130,
  98007,
  97872,
  97724,
  97563,
  97387,
  97197,
  96993,
  96776,
  96546,
  96304,
  96049,
  95778,
  95489,
  95180,
  94851,
  94501,
  94131,
  93741,
  93329,
  92892,
  92425,
  91923,
  91382,
  90797,
  90164,
  89476,
  88726,
  87907,
  87010,
  86024,
  84941,
  83751,
  82442,
  80998,
  79402,
  77633,
  75671,
  73496,
  71088,
  68423,
  65478,
  62233,
  58680,
  54828,
  50706,
  46362,
  41868,
  37319,
  32821,
  28469,
  24328,
  20444,
  16860,
  13618,
  10750,
  8277,
  6204,
  4516,
  3185,
  2171,
  1426,
  900,
  544,
  314,
  172,
  89,
  44,
  20,
  9,
  4,
  1,
  0)




Data_as<-data.frame(Hommes,Femmes) ## TABLE DE MORTALITE
Datatable<-Data_as









































  
}










    